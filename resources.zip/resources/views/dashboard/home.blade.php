@extends('dashboard.layouts.app')
@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="content">
                <img src="" alt="" class="img-fluid mb-5 w-100" >
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-lg-8 col-md-12">
            <div class="row">
                <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="">
                                <p class="mb-2 text-secondary"></p>
                                <div class="d-flex flex-wrap justify-content-start align-items-center">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="">
                                <p class="mb-2 text-secondary"></p>
                                <div class="d-flex flex-wrap justify-content-start align-items-center">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="">
                            <p class="mb-2 text-secondary"></p>
                            <div class="d-flex flex-wrap justify-content-start align-items-center">

                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center flex-wrap p-5">

                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-8">
            <div class="card card-block card-stretch card-height">
                <div class="card-header card-header-border d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title"></h4>
                </div>
                </div>
                <div class="card-body-list">
                <ul class="list-style-3 mb-0">

                </ul>
                </div>
            </div>

        </div>


    </div>
    <!-- Page end  -->
</div>


@endsection
