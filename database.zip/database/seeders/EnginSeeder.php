<?php

namespace Database\Seeders;

use App\Models\Engin;
use App\Models\CategorieEngin;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\Json;

class EnginSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        



    }
}
